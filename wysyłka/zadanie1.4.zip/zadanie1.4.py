for i in range(5):
    print("**********")
    print(" **********")

for i in range(1,5):
        for _ in range(2):
                print("**" * i)

for i in reversed(range(1,6)):
        print("*" * i)